#Requires -Version 7.0
<#
.SYNOPSIS
    Install all PowerShell module dependencies for this repo.
.DESCRIPTION
    Installs AWS.Tools (modular) and Pester. 
    Run once after cloning or when adding new AWS service modules.
    Does NOT require admin — installs to CurrentUser scope.
.EXAMPLE
    . ./Tools/Install-Dependencies.ps1
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$awsModules = @(
    'AWS.Tools.Installer'
    'AWS.Tools.Common'
    'AWS.Tools.Organizations'
    'AWS.Tools.SecurityToken'
    'AWS.Tools.IdentityManagement'
    'AWS.Tools.EC2'
    'AWS.Tools.RDS'
    'AWS.Tools.S3'
    'AWS.Tools.SimpleSystemsManagement'
    'AWS.Tools.SecretsManager'
    'AWS.Tools.CloudTrail'
    'AWS.Tools.SecurityHub'
    'AWS.Tools.GuardDuty'
    'AWS.Tools.Config'
)

Write-Host "Installing PSGallery dependencies..." -ForegroundColor Cyan

# Trust PSGallery for this session
Set-PSRepository -Name PSGallery -InstallationPolicy Trusted

# Pester 5.x
if (-not (Get-Module -ListAvailable -Name Pester | Where-Object { $_.Version -ge '5.0.0' })) {
    Write-Host "Installing Pester 5.x..."
    Install-Module -Name Pester -MinimumVersion '5.0.0' -Scope CurrentUser -Force
}

# PSScriptAnalyzer
if (-not (Get-Module -ListAvailable -Name PSScriptAnalyzer)) {
    Write-Host "Installing PSScriptAnalyzer..."
    Install-Module -Name PSScriptAnalyzer -Scope CurrentUser -Force
}

# AWS.Tools.Installer first, then use it for the rest
if (-not (Get-Module -ListAvailable -Name 'AWS.Tools.Installer')) {
    Write-Host "Installing AWS.Tools.Installer..."
    Install-Module -Name 'AWS.Tools.Installer' -Scope CurrentUser -Force
}

Import-Module AWS.Tools.Installer

foreach ($module in ($awsModules | Where-Object { $_ -ne 'AWS.Tools.Installer' })) {
    if (-not (Get-Module -ListAvailable -Name $module)) {
        Write-Host "Installing $module..."
        Install-AWSToolsModule -Name $module -Scope CurrentUser -CleanUp -Force
    }
    else {
        Write-Host "$module already installed." -ForegroundColor Gray
    }
}

Write-Host "`nAll dependencies installed." -ForegroundColor Green
Write-Host "Run: Invoke-Pester ./Tests -Output Detailed" -ForegroundColor Cyan
