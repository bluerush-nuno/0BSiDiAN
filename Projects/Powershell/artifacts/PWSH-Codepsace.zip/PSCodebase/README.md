# PSCodebase

PowerShell automation codebase — AWS multi-account / SecDevOps operations.

## Structure

```
PSCodebase/
├── Modules/          # Reusable PS modules (.psm1 + .psd1), one folder per module
│   ├── AWS/          # AWS.Tools wrappers, multi-account helpers
│   ├── Security/     # IAM audit, secrets hygiene, SG review
│   ├── Networking/   # VPC, TGW, SG utilities
│   ├── Utility/      # Common helpers (logging, formatting, retry)
│   └── Logging/      # Structured logging module
├── Scripts/          # Operational scripts — consume modules, do work
│   ├── AWS/
│   │   ├── IAM/
│   │   ├── EC2/
│   │   ├── RDS/
│   │   ├── S3/
│   │   ├── Org/
│   │   └── VPC/
│   ├── Security/
│   ├── Ops/
│   └── Reporting/
├── Config/           # Environment configs (no secrets here)
│   ├── Environments/ # Per-env JSON/psd1 config files
│   └── Schemas/      # JSON Schema for config validation
├── Tests/            # Pester tests mirror module structure
│   ├── Unit/
│   └── Integration/
├── Docs/
│   ├── Runbooks/     # Operational runbooks (Markdown)
│   ├── Architecture/ # Architecture decision context
│   └── Decisions/    # ADRs
├── Tools/            # Repo-local tooling (linters, formatters, helpers)
├── Build/            # Build/publish scripts (module packaging, PSGallery)
└── .github/
    └── workflows/    # CI/CD (PSScriptAnalyzer, Pester, publish)
```

## Prerequisites

- PowerShell 7.x
- `AWS.Tools` modules (modular, not monolithic AWSPowerShell)
- Pester 5.x for tests
- PSScriptAnalyzer for linting

## Module Installation

```powershell
. ./Tools/Install-Dependencies.ps1
```

## Running Tests

```powershell
Invoke-Pester ./Tests -Output Detailed
```

## Conventions

- All scripts use `#Requires` for explicit dependency declaration
- No implicit AWS profile/region defaults — always explicit `-ProfileName` / `-Region`
- Secrets via SSM Parameter Store or Secrets Manager — never in config files or code
- Error handling: `try/catch` with structured logging via the `Logging` module
- `Set-StrictMode -Version Latest` in all scripts and modules
