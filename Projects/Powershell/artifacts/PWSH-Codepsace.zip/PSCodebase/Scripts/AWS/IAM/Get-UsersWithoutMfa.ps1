#Requires -Version 7.0
#Requires -Modules @{ ModuleName='AWS.Tools.IdentityManagement'; ModuleVersion='4.0.0' }
#Requires -Modules @{ ModuleName='AWS.Tools.SecurityToken'; ModuleVersion='4.0.0' }

<#
.SYNOPSIS
    Enumerate IAM users with console access but no MFA enrolled, across all org accounts.
.DESCRIPTION
    Multi-account scan. Assumes an org-level audit role in each account.
    Outputs structured objects — pipe to Export-Csv, ConvertTo-Json, etc.

.PARAMETER ManagementProfileName
    AWS credential profile for the management account (for Org enumeration).
.PARAMETER AuditRoleName
    IAM role name assumed in each member account. Must exist in all accounts.
.PARAMETER OutputPath
    Optional. Path to write CSV report. If omitted, outputs to pipeline.
.PARAMETER ExcludeAccountIds
    Account IDs to skip.

.EXAMPLE
    .\Get-UsersWithoutMfa.ps1 -ManagementProfileName 'org-mgmt' -AuditRoleName 'OrgAuditRole'
.EXAMPLE
    .\Get-UsersWithoutMfa.ps1 -ManagementProfileName 'org-mgmt' -AuditRoleName 'OrgAuditRole' -OutputPath 'C:\Reports\no-mfa.csv'

.NOTES
    !! This script is READ-ONLY — no changes made to any account. !!
    Blast radius: None. Audit only.
    CIS AWS v1.5: 1.5 — Ensure MFA is enabled for all IAM users with console password
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$ManagementProfileName,

    [Parameter(Mandatory)]
    [string]$AuditRoleName,

    [string]$OutputPath,

    [string[]]$ExcludeAccountIds = @()
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Load local modules from repo — adjust path if running from a different working dir
$repoRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
Import-Module "$repoRoot/Modules/AWS/AWS.psd1"     -Force
Import-Module "$repoRoot/Modules/Logging/Logging.psm1" -Force

Initialize-Logger -LogLevel 'INFO'

$results = [System.Collections.Generic.List[PSCustomObject]]::new()

try {
    $accounts = Get-ActiveOrgAccounts -ManagementProfileName $ManagementProfileName `
                                      -ExcludeAccountIds $ExcludeAccountIds

    Write-Log -Level INFO -Message "Scanning $($accounts.Count) accounts for users without MFA."

    foreach ($account in $accounts) {
        Write-Log -Level DEBUG -Message "Processing account" -Context @{ AccountId = $account.Id; AccountName = $account.Name }

        try {
            # Assume audit role in member account
            $stsResponse = Use-STSRole `
                -RoleArn          "arn:aws:iam::$($account.Id):role/$AuditRoleName" `
                -RoleSessionName  "mfa-audit-$(Get-Date -Format yyyyMMddHHmm)" `
                -ProfileName      $ManagementProfileName

            $creds = $stsResponse.Credentials
            Set-AWSCredential `
                -AccessKey    $creds.AccessKeyId `
                -SecretKey    $creds.SecretAccessKey `
                -SessionToken $creds.SessionToken

            $usersWithPassword = Get-IAMUserList | Where-Object {
                # LoginProfile exists = console access enabled
                try { Get-IAMLoginProfile -UserName $_.UserName | Out-Null; $true }
                catch { $false }
            }

            foreach ($user in $usersWithPassword) {
                $mfaDevices = Get-IAMMFADevice -UserName $user.UserName
                if ($mfaDevices.Count -eq 0) {
                    $results.Add([PSCustomObject]@{
                        AccountId   = $account.Id
                        AccountName = $account.Name
                        UserName    = $user.UserName
                        UserArn     = $user.Arn
                        CreateDate  = $user.CreateDate
                        Finding     = 'ConsoleAccessNoMFA'
                        Severity    = 'High'
                        CIS         = '1.5'
                    })
                    Write-Log -Level WARN -Message "No MFA: $($user.UserName)" -Context @{ AccountId = $account.Id }
                }
            }
        }
        catch {
            Write-Log -Level ERROR -Message "Failed to process account $($account.Id): $($_.Exception.Message)"
            # Continue to next account — don't abort the whole run
        }
        finally {
            # Clear assumed-role creds before next iteration
            Clear-AWSCredential -ErrorAction SilentlyContinue
        }
    }

    Write-Log -Level INFO -Message "Scan complete. Findings: $($results.Count)"

    if ($OutputPath) {
        $results | Export-Csv -Path $OutputPath -NoTypeInformation -Encoding UTF8
        Write-Log -Level INFO -Message "Report written to $OutputPath"
    }
    else {
        $results
    }
}
catch {
    Write-Log -Level ERROR -Message "Fatal error: $($_.Exception.Message)"
    exit 1
}
