# prod.psd1 — Production environment configuration
# NO secrets here. Secrets live in SSM Parameter Store or Secrets Manager.
# Reference SSM paths, not values.

@{
    Environment            = 'prod'
    ManagementAccountId    = '123456789012'
    ManagementProfileName  = 'org-mgmt-prod'
    DefaultRegion          = 'us-east-1'
    SecondaryRegion        = 'us-west-2'

    # IAM role assumed in each member account for cross-account ops
    AuditRoleName          = 'OrgAuditRole'
    OpsRoleName            = 'OrgOpsRole'

    # SSM paths for secrets — values pulled at runtime, never stored here
    Secrets = @{
        SlackWebhookPath   = '/prod/notifications/slack-webhook'
        PagerDutyKeyPath   = '/prod/notifications/pagerduty-key'
    }

    # Notification targets
    AlertEmail             = 'ops-alerts@example.com'

    # Account IDs to exclude from org-wide scans
    ExcludedAccountIds     = @(
        '123456789012'   # management account — scanned separately
    )

    # Tagging enforcement
    RequiredTags           = @('Environment', 'Owner', 'CostCenter', 'Project')
}
