#Requires -Version 7.0

<#
.SYNOPSIS
    Structured logging module. Outputs to console (color-coded) and optional log file.
.NOTES
    Use this instead of bare Write-Host / Write-Output in scripts.
    Structured for future ingestion into CloudWatch Logs or similar.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$script:LogFile   = $null
$script:LogLevel  = 'INFO'   # DEBUG | INFO | WARN | ERROR
$script:Levels    = @{ DEBUG = 0; INFO = 1; WARN = 2; ERROR = 3 }

function Initialize-Logger {
    <#
    .SYNOPSIS
        Configure the logger for the current session.
    .EXAMPLE
        Initialize-Logger -LogFile 'C:\Logs\ops.log' -LogLevel 'DEBUG'
    #>
    [CmdletBinding()]
    param(
        [string]$LogFile,
        [ValidateSet('DEBUG','INFO','WARN','ERROR')]
        [string]$LogLevel = 'INFO'
    )
    $script:LogFile  = $LogFile
    $script:LogLevel = $LogLevel
}

function Write-Log {
    <#
    .SYNOPSIS
        Write a structured log entry.
    .EXAMPLE
        Write-Log -Level WARN -Message "SG rule allows 0.0.0.0/0 on port 22" -Context @{ AccountId = '123456789012' }
    #>
    [CmdletBinding()]
    param(
        [ValidateSet('DEBUG','INFO','WARN','ERROR')]
        [string]$Level = 'INFO',

        [Parameter(Mandatory)]
        [string]$Message,

        [hashtable]$Context = @{}
    )

    if ($script:Levels[$Level] -lt $script:Levels[$script:LogLevel]) { return }

    $entry = [ordered]@{
        timestamp = (Get-Date -Format 'yyyy-MM-ddTHH:mm:ssZ')
        level     = $Level
        message   = $Message
        context   = $Context
    }

    $color = switch ($Level) {
        'DEBUG' { 'Gray'    }
        'INFO'  { 'Cyan'    }
        'WARN'  { 'Yellow'  }
        'ERROR' { 'Red'     }
    }

    $formatted = "$($entry.timestamp) [$Level] $Message"
    if ($Context.Count -gt 0) {
        $ctxStr = ($Context.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join ' '
        $formatted += " | $ctxStr"
    }

    Write-Host $formatted -ForegroundColor $color

    if ($script:LogFile) {
        $formatted | Out-File -FilePath $script:LogFile -Append -Encoding utf8
    }
}

Export-ModuleMember -Function 'Initialize-Logger', 'Write-Log'
