@{
    ModuleVersion     = '1.0.0'
    GUID              = '00000000-0000-0000-0000-000000000001'  # Replace: [guid]::NewGuid()
    Author            = ''
    CompanyName       = ''
    Description       = 'AWS multi-account helper module for cross-account operations via AWS Organizations.'
    PowerShellVersion = '7.0'

    RequiredModules   = @(
        @{ ModuleName = 'AWS.Tools.Common';        ModuleVersion = '4.0.0' }
        @{ ModuleName = 'AWS.Tools.Organizations'; ModuleVersion = '4.0.0' }
        @{ ModuleName = 'AWS.Tools.SecurityToken'; ModuleVersion = '4.0.0' }
    )

    RootModule        = 'AWS.psm1'

    FunctionsToExport = @(
        'Get-ActiveOrgAccounts'
        'Invoke-CrossAccountCommand'
        'Get-AssumedRoleCredentials'
    )

    CmdletsToExport   = @()
    VariablesToExport = @()
    AliasesToExport   = @()

    PrivateData = @{
        PSData = @{
            Tags       = @('AWS', 'MultiAccount', 'Organizations', 'SecDevOps')
            ProjectUri = ''
        }
    }
}
