#Requires -Version 7.0
#Requires -Modules @{ ModuleName='AWS.Tools.Common'; ModuleVersion='4.0.0' }
#Requires -Modules @{ ModuleName='AWS.Tools.Organizations'; ModuleVersion='4.0.0' }
#Requires -Modules @{ ModuleName='AWS.Tools.SecurityToken'; ModuleVersion='4.0.0' }

<#
.SYNOPSIS
    AWS multi-account helper module.
.DESCRIPTION
    Wrappers around AWS.Tools for multi-account/multi-region operations via AWS Organizations.
    Assumes role per account using a standard org-wide audit/ops role.
.NOTES
    Module:  AWS
    Version: 1.0.0
    Conventions:
      - Always explicit -ProfileName and -Region. No implicit defaults.
      - Returns structured objects. No string parsing.
      - All public functions in separate files under Public/
      - All private helpers under Private/
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Load private helpers first
$privateFiles = Get-ChildItem -Path "$PSScriptRoot/Private" -Filter '*.ps1' -Recurse -ErrorAction SilentlyContinue
foreach ($file in $privateFiles) {
    . $file.FullName
}

# Load public functions
$publicFiles = Get-ChildItem -Path "$PSScriptRoot/Public" -Filter '*.ps1' -Recurse -ErrorAction SilentlyContinue
foreach ($file in $publicFiles) {
    . $file.FullName
}

# Export only public functions — explicit is better than wildcard
Export-ModuleMember -Function @(
    'Get-ActiveOrgAccounts'
    'Invoke-CrossAccountCommand'
    'Get-AssumedRoleCredentials'
)
