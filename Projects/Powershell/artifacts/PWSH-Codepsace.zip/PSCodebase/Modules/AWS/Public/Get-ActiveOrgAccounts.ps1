function Get-ActiveOrgAccounts {
    <#
    .SYNOPSIS
        Returns all ACTIVE accounts in the AWS Organization.
    .PARAMETER ManagementProfileName
        AWS credential profile for the management/root account.
    .PARAMETER ExcludeAccountIds
        Account IDs to skip (e.g., management account itself).
    .EXAMPLE
        Get-ActiveOrgAccounts -ManagementProfileName 'org-mgmt' -ExcludeAccountIds '123456789012'
    #>
    [CmdletBinding()]
    [OutputType([Amazon.Organizations.Model.Account[]])]
    param(
        [Parameter(Mandatory)]
        [string]$ManagementProfileName,

        [string[]]$ExcludeAccountIds = @()
    )

    try {
        $accounts = Get-ORGAccountList -ProfileName $ManagementProfileName |
            Where-Object { $_.Status -eq 'ACTIVE' } |
            Where-Object { $_.Id -notin $ExcludeAccountIds }

        Write-Verbose "Found $($accounts.Count) active accounts."
        return $accounts
    }
    catch {
        Write-Error "Failed to enumerate org accounts: $($_.Exception.Message)"
        throw
    }
}
