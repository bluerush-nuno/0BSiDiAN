#Requires -Version 7.0
#Requires -Modules @{ ModuleName='Pester'; ModuleVersion='5.0.0' }

<#
.SYNOPSIS
    Unit tests for the AWS module — Get-ActiveOrgAccounts
.NOTES
    These mock all AWS API calls. No live AWS connection required.
    Run: Invoke-Pester ./Tests -Output Detailed
#>

BeforeAll {
    $repoRoot = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
    Import-Module "$repoRoot/Modules/AWS/AWS.psd1" -Force
}

Describe 'Get-ActiveOrgAccounts' {

    Context 'When org has active and suspended accounts' {

        BeforeEach {
            Mock Get-ORGAccountList {
                return @(
                    [PSCustomObject]@{ Id = '111111111111'; Name = 'prod';    Status = 'ACTIVE'    }
                    [PSCustomObject]@{ Id = '222222222222'; Name = 'staging'; Status = 'ACTIVE'    }
                    [PSCustomObject]@{ Id = '333333333333'; Name = 'old';     Status = 'SUSPENDED' }
                )
            } -ModuleName AWS
        }

        It 'Returns only ACTIVE accounts' {
            $result = Get-ActiveOrgAccounts -ManagementProfileName 'test-profile'
            $result.Count | Should -Be 2
            $result.Status | Should -Not -Contain 'SUSPENDED'
        }

        It 'Excludes specified account IDs' {
            $result = Get-ActiveOrgAccounts -ManagementProfileName 'test-profile' `
                                            -ExcludeAccountIds '111111111111'
            $result.Count | Should -Be 1
            $result[0].Id | Should -Be '222222222222'
        }

        It 'Returns empty array when all accounts excluded' {
            $result = Get-ActiveOrgAccounts -ManagementProfileName 'test-profile' `
                                            -ExcludeAccountIds '111111111111','222222222222'
            $result.Count | Should -Be 0
        }
    }

    Context 'When AWS API throws' {

        BeforeEach {
            Mock Get-ORGAccountList { throw 'Access Denied' } -ModuleName AWS
        }

        It 'Re-throws the error' {
            { Get-ActiveOrgAccounts -ManagementProfileName 'test-profile' } | Should -Throw
        }
    }
}
